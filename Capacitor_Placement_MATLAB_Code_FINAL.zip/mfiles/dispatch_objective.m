function F = dispatch_objective(Ploss_kW, Vmag, k, k_prev, Vmin, Vmax, lam_v, lam_s)
% DISPATCH_OBJECTIVE
%
%   F(t) = Ploss(t)
%          + lam_v * sum_i [ max(0, V_i-Vmax)^2 + max(0, Vmin-V_i)^2 ]
%          + sum_i  lam_s_i * |k_i(t) - k_i(t-1)|
%
%   exactly as defined in proposal Section 5.1, now with lam_s allowed to
%   vary per bank. Used identically by greedy_dispatch, pso_dispatch, and
%   evaluate_schedule so every caller is scoring the same objective.
%
%   INPUTS
%     Ploss_kW : total I^2R loss (kW) at this interval, from bfs_loadflow
%     Vmag     : [N x 1] bus voltage magnitudes (p.u.) at this interval
%     k        : [N x 1] step-count vector at this interval (0 for
%                non-candidate buses)
%     k_prev   : [N x 1] step-count vector at the PREVIOUS interval
%                (this is what makes the problem time-coupled / multi-stage)
%     Vmin, Vmax : statutory voltage band (p.u.), e.g. 0.95, 1.05
%     lam_v    : penalty weight on voltage violations (kW per p.u.^2)
%     lam_s    : penalty weight per switching operation. Either:
%                  - a SCALAR: the classic form, one price for every bank
%                  - an [N x 1] VECTOR: a per-bank price. This is what
%                    powers greedy's budget-aware pricing (see
%                    greedy_dispatch.m) -- a bank running low on its daily
%                    switching allowance is charged more per further
%                    operation, so the search steers away from it before
%                    it hits the hard cap, rather than only discovering
%                    the cap after the fact.
%
%   NOTE: this function shapes the SEARCH via a price signal. It is not
%   what makes the daily switching cap Smax true -- that is a hard
%   constraint enforced separately and unconditionally by
%   enforce_switch_limit.m, regardless of how lam_s was tuned.
%
%   OUTPUT
%     F : scalar cost (kW-equivalent) to be minimized

    viol = sum( max(0, Vmag - Vmax).^2 + max(0, Vmin - Vmag).^2 );

    dk = abs(k - k_prev);
    if isscalar(lam_s)
        switch_cost = lam_s * sum(dk);
    else
        switch_cost = sum(lam_s(:) .* dk);
    end

    F = Ploss_kW + lam_v*viol + switch_cost;
end
