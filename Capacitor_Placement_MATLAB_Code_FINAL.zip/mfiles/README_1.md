# Optimal Multi-Stage Capacitor Placement and Control Algorithm (MATLAB)

MATLAB code for optimal capacitor placement and multi-stage control on the
IEEE 33-bus radial distribution system. Capacitor locations and sizes are chosen
offline using sensitivity indices, and then the capacitor steps are switched
hour by hour over a 24-hour load profile, with a limit on how many switching
operations each bank can make in a day.

Three cases are compared:
- Case A: no compensation
- Case B: fixed capacitor bank (one setting for the whole day)
- Case C: switched capacitor banks using greedy dispatch, refined by PSO

## How to run

1. Keep all the `.m` files in the same folder, or add the folder to the MATLAB path.
2. Run `validate_loadflow.m` first. It should print `VALIDATION PASSED`, with a
   total loss of 202.677 kW and a minimum voltage of 0.9131 p.u. at bus 18.
   These are the standard values for the IEEE 33-bus system. If this check
   fails, the rest of the results can't be trusted.
3. Run `run_cases.m`. To get the results struct in the workspace, use:
   ```matlab
   results = main();
   ```
4. PSO is controlled by `cfg.RUN_PSO` in `main.m`. It takes around 30-90 s.

## Files

| File | Description |
|---|---|
| `ieee33_data.m` | Line and load data of the IEEE 33-bus system (Baran & Wu / MATPOWER case33bw) |
| `build_topology.m` | Builds the radial tree structure and per-unit impedances |
| `build_load_profile.m` | Makes the 24-hour P and Q load matrices from load-class curves |
| `bfs_loadflow.m` | Backward-Forward Sweep load flow |
| `validate_loadflow.m` | Checks the load flow against the benchmark values |
| `compute_LSF_VSI.m` | Calculates the Loss Sensitivity Factor and Voltage Stability Index |
| `size_capacitors.m` | Selects the candidate buses and sizes the capacitors |
| `size_fixed_bank.m` | Finds the fixed capacitor setting for Case B |
| `dispatch_objective.m` | Objective function F(t) for dispatch (loss + voltage penalty + switching cost) |
| `enforce_switch_limit.m` | Makes sure no bank switches more than Smax times in a day |
| `evaluate_schedule.m` | Calculates daily loss, voltages and switching count for a full schedule |
| `greedy_dispatch.m` | Greedy hour-by-hour dispatch |
| `pso_dispatch.m` | PSO dispatch, starting from the greedy solution |
| `main.m` | Main program, runs all three cases |
| `run_cases.m` | Script that calls `main()` |
| `plot_results.m` | Plots the results |

## Implementation notes

**Capacitor sizing.** The candidate buses on the same lateral are nested,
since the reactive power flowing through a downstream bus also flows through
the buses above it. If each bus were sized using its full downstream
reactive power, the same kVAr would be counted more than once and the feeder
would be overcompensated. So each candidate is sized only for its own
portion:

```
Qexcl(c) = Qcum(c) - sum of Qcum(d) for the nearest downstream candidates d
```

The total installed kVAr is also limited to `budgetFrac` times the total
reactive demand of the feeder. Buses are given capacitors in order of
priority until this budget is used up.

**Step size.** We first used 150 kVAr steps. Most candidate buses needed
less than 150 kVAr, so they got zero steps and only 3 buses received a
capacitor. With so little capacitance there was nothing to switch, and
dispatch gave the same result as the fixed bank. We changed to 50 kVAr steps
with `Nmax = 15`, which keeps the 750 kVAr maximum per bus.

**Switching limit.** The daily limit on switching operations,
`sum_t |k_i(t) - k_i(t-1)| <= Smax`, is enforced by `enforce_switch_limit.m`.
Once a bank has used all its switching operations for the day, it is not
allowed to change any more. Both greedy and PSO send their final schedule
through this function.

**Switching cost.** In `dispatch_objective.m`, `lam_s` can be a single value
or a vector with one value per bank. The greedy method raises a bank's cost
as it gets close to its limit, so it doesn't use up all its switching early
in the day.

**Greedy and PSO.** Greedy does not accept any move that would take a bank
over its switching limit. PSO starts from the greedy solution. Since PSO
always keeps the best solution found so far, its result can't be worse than
greedy's. The field `info.improved_on_seed` shows whether PSO actually found
something better, and `info.method` shows whether the Global Optimization
Toolbox or our own PSO code was used.

**Evaluation.** All three cases are evaluated with the same function
(`evaluate_schedule.m`), so the printed values, the results struct and the
plots always match. Energy is calculated with `dt = 24/T`, so the code also
works for 15-minute steps (`cfg.T = 96`).

## Results (default settings)

```
Profile: dual-peak    Case B sized at: average load    Qstep 50 kVAr
Candidates (9): buses 3, 4, 6, 14, 24, 29, 30, 31, 32
Installed: 1,500 kVAr

Case A (uncompensated)  : 2,095.4 kWh/day, min V = 0.9248 p.u.
Case B (fixed bank)     : 1,408.6 kWh/day, min V = 0.9355 p.u.   (32.8% vs A)
Case C (dispatch)       : 1,348.8 kWh/day, min V = 0.9376 p.u.   (35.6% vs A)

Case C beats Case B by 4.24%
Max switching operations/bank: 12  (Smax = 12)
```

By default the load profile has two peaks (`cfg.loadProfile = 'dual'`), in
the morning and in the evening, and the fixed bank for Case B is sized at
the average load (`cfg.fixedSizingPoint = 'average'`). With a single peak,
one fixed setting can be close to the best choice for the whole day. Real
feeders usually have two peaks, and fixed banks are normally sized for
typical load rather than the worst hour.

To run the comparison that favors the fixed bank instead, set
`cfg.loadProfile = 'single'` and `cfg.fixedSizingPoint = 'peak'`. In that
case, dispatch is about 1.3% better than the fixed bank instead of 4.2%.

## Limitations

At peak load, neither Case B nor Case C brings every bus up to 0.95 p.u.;
the lowest voltage in Case C is 0.9376 p.u. We tried increasing the kVAr
budget and adding more candidate buses, but the minimum voltage did not
improve. This seems to be a limit of the placement and sizing method on this
feeder. Possible ways to fix it are a larger candidate set, a different
placement index, or coordinating the capacitors with the OLTC.
