function results = main(cfg)
% MAIN  Single entry point for the Optimal Multi-Stage Capacitor Placement
%   & Control project on the IEEE 33-bus radial distribution system.
%
%   USAGE
%     results = main();                 % all defaults (see below)
%     results = main(cfg);              % override any subset of the defaults
%
%   Every field of cfg is optional; anything you leave out falls back to
%   the default below. Examples:
%     cfg.RUN_PSO = true;               results = main(cfg);   % add PSO refinement
%     cfg.lam_v   = 5e5;  cfg.lam_s = 0.1;                      % re-weight objective
%     cfg.plots   = false;              results = main(cfg);   % headless, no figures
%
%   ------------------------------------------------------------------
%   WHY THESE DEFAULTS (not the original 150 kVAr / budgetFrac 0.75 / lam_s 0.5)
%   ------------------------------------------------------------------
%   Qstep=150 with the (correct) exclusive-flow sizing in size_capacitors.m
%   floors most candidate buses' exclusive share to ZERO steps -- 150 kVAr
%   is coarser than what's left over once nested overlap is removed, no
%   matter how large budgetFrac is set. Only 3 sites ever get funded, which
%   starves the system into a regime where dispatch has nothing left to
%   optimize (near-constant undercompensation all day) and can no longer
%   demonstrate any advantage over a simple fixed bank.
%
%   Shrinking Qstep to 50 kVAr (with Nmax raised to 15, keeping the same
%   750 kVAr per-site ceiling) recovers a much richer 8-site candidate set,
%   genuinely non-overlapping and using the full sizing budget. Under this
%   configuration, greedy dispatch (with a modest lam_s and the escalating
%   per-bank pricing) measurably outperforms a correctly-sized fixed bank
%   again, and the switching count sits sensibly under Smax.
%
%   These values were chosen by a parameter sweep (documented in the
%   project's chat history / report appendix, not repeated here) trading
%   off: number of funded candidates, Case C vs. Case B separation,
%   voltage-band performance, and switching-operation counts. They are
%   defaults, not laws -- cfg lets you override any of them for your own
%   sensitivity study.
%
%   CONFIG FIELDS (defaults in parentheses)
%     .RUN_PSO    (true)  run the PSO/GA refinement stage in addition to
%                         greedy. On by default: PSO is seeded from the
%                         greedy solution, so it can never return a worse
%                         result -- there is no downside beyond runtime.
%     .T          (24)    number of load-profile intervals (24 = 1-hour resolution)
%     .loadProfile ('dual') 'dual' = realistic two-peak daily load shape
%                         (residential morning+evening, commercial two
%                         office-hours humps); 'single' = the original
%                         smooth single-peak curves. A single-peak day is
%                         the one condition where a fixed bank can be
%                         near-optimal all day, so 'dual' is both more
%                         realistic and a fairer test of dispatch.
%     .fixedSizingPoint ('average') operating point Case B's fixed bank is
%                         sized against: 'average' (how a utility actually
%                         specifies one) or 'peak' (idealized -- the fixed
%                         bank is effectively told the worst case in
%                         advance, which understates dispatch's value).
%     .topK       (8)     top-LSF buses to include as candidates
%     .bottomK    (8)     bottom-VSI buses to include as candidates
%     .Qstep      (50)    capacitor step size (kVAr) -- see note above
%     .Nmax       (15)    max steps per site  (=> max Nmax*Qstep = 750 kVAr/site)
%     .budgetFrac (1.0)   total installed kVAr as a fraction of feeder total Q
%     .Vmin       (0.95)  statutory lower voltage band (p.u.)
%     .Vmax       (1.05)  statutory upper voltage band (p.u.)
%     .lam_v      (1e6)   penalty weight on voltage violations
%     .lam_s      (0.05)  BASE switching-penalty weight (greedy escalates
%                         this per-bank as an allowance is used up; see
%                         greedy_dispatch.m)
%     .Smax       (12)    HARD daily switching-operation cap per bank,
%                         enforced unconditionally by enforce_switch_limit.m
%     .pso.SwarmSize     (40) PSO swarm size (only used if RUN_PSO)
%     .pso.MaxIterations (60) PSO iterations   (only used if RUN_PSO)
%     .plots      (true)  generate the required figures via plot_results()
%     .verbose    (true)  print the step-by-step console report
%
%   RETURNS  results struct with (among others):
%     .cfg                the fully-resolved configuration actually used
%     .system             N, bases, nominal loads, bus-class assignment
%     .profile            Pmat, Qmat  [T x N] load trajectories
%     .validation         base-case load-flow check vs. published benchmark
%     .sensitivity        peak interval, LSF, VSI, cumulative P/Q
%     .sizing             candidate buses, per-site step limits Ncap, Qstep,
%                         budgetFrac, and the full sizing info struct from
%                         size_capacitors() (pool, Qexcl, budget, installed, table)
%     .caseA              uncompensated:  Ploss/Vmin/Vmag (T-series), Edaily, ...
%     .caseB              fixed capacitor 24/7:  same fields + capFixed
%     .caseC_greedy       greedy dispatch: + K schedule, switch_ops, runtime
%     .caseC_pso          PSO dispatch (only present if RUN_PSO)
%     .caseC              alias to whichever Case C is the "reported" one
%     .summary            headline numbers (daily losses, reductions, compliance)
%
%   Depends on: ieee33_data, build_topology, build_load_profile, bfs_loadflow,
%   compute_LSF_VSI, size_capacitors, enforce_switch_limit, evaluate_schedule,
%   dispatch_objective, greedy_dispatch, pso_dispatch, plot_results.

    if nargin < 1; cfg = struct(); end
    cfg = merge_config(cfg);
    vp  = @(varargin) fprintf_if(cfg.verbose, varargin{:});

    %% ---------------- Step 1: Data & Load Profile ----------------
    [branch, Pd, Qd, Vbase, Sbase] = ieee33_data();
    N    = numel(Pd);
    topo = build_topology(branch, Vbase, Sbase, N);

    T = cfg.T;
    [Pmat, Qmat, bus_class] = build_load_profile(Pd, Qd, N, T, cfg.loadProfile);

    vp('=== Step 1: Data & Load Profile ===\n');
    vp('System: IEEE 33-bus, %.0f kV base, nominal load %.0f kW + %.0f kVAr, profile=%s\n', ...
        Vbase/1e3, sum(Pd), sum(Qd), cfg.loadProfile);

    %% ---------------- Step 2: Load-Flow Validation ----------------
    [Vnom, ~, Ploss_nom, ~, iters_nom, conv_nom] = bfs_loadflow(topo, Pd, Qd);
    [minV_nom, minBus_nom] = min(Vnom);
    valPassed = (abs(Ploss_nom - 202.7) < 0.5) && (minBus_nom == 18);

    vp('\n=== Step 2: Load-Flow Validation (base case, nominal load) ===\n');
    vp('Converged=%d (%d iters). Loss=%.3f kW (pub. ~202.7). MinV=%.4f p.u. at bus %d (pub. ~0.9131 @ 18)\n', ...
        conv_nom, iters_nom, Ploss_nom, minV_nom, minBus_nom);
    assert(valPassed, ...
        'Load-flow validation FAILED -- fix data/solver before proceeding.');

    %% ---------------- Step 3: Candidate Selection (at peak load) ----------------
    totalP = sum(Pmat, 2);
    [~, t_peak] = max(totalP);
    Pp = Pmat(t_peak, :)';
    Qp = Qmat(t_peak, :)';
    [Vp, ~, Ploss_peak] = bfs_loadflow(topo, Pp, Qp);

    [LSF, VSI, Pcum, Qcum] = compute_LSF_VSI(topo, Vp, Pp, Qp);

    [candidates, Ncap, sizingInfo] = size_capacitors(topo, LSF, VSI, Qcum, ...
        cfg.topK, cfg.bottomK, cfg.Qstep, cfg.Nmax, cfg.budgetFrac);

    vp('\n=== Step 3-4: Candidate Selection & Sizing ===\n');
    vp('Peak interval = hour %d, peak total load = %.1f kW, loss at peak = %.2f kW\n', ...
        t_peak - 1, totalP(t_peak), Ploss_peak);
    vp('Sizing budget: %.0f kVAr (%.0f%% of feeder total %.0f kVAr), installed = %.0f kVAr\n', ...
        sizingInfo.budget, 100*cfg.budgetFrac, sizingInfo.Qcum_total, sizingInfo.installed);
    vp('Candidate buses (%d): %s\n', numel(candidates), mat2str(candidates'));
    vp('Step limits N_i:\n');
    for i = 1:numel(candidates)
        c = candidates(i);
        vp('  Bus %2d : N_i = %d  (max %d kVAr)\n', c, Ncap(c), Ncap(c)*cfg.Qstep);
    end
    if isempty(candidates)
        error('No candidates funded -- check budgetFrac/Qstep/Nmax.');
    end

    %% ---------------- Dispatch weights & voltage band ----------------
    Vmin = cfg.Vmin;  Vmax = cfg.Vmax;
    lam_v = cfg.lam_v; lam_s = cfg.lam_s; Smax = cfg.Smax;

    %% ---------------- Step 6a: Case A -- Uncompensated ----------------
    vp('\n=== Step 6: Running Case A (uncompensated) ===\n');
    PlossA = zeros(T,1); VminA = zeros(T,1); VmagA = zeros(T,N);
    for t = 1:T
        [Vf, ~, Plf] = bfs_loadflow(topo, Pmat(t,:)', Qmat(t,:)');
        PlossA(t) = Plf; VminA(t) = min(Vf); VmagA(t,:) = Vf';
    end

    %% ---------------- Step 6b: Case B -- Fixed Capacitor (sized once, energized 24/7) ----------------
    % HOW CASE B IS SIZED, AND WHY IT MATTERS FOR A FAIR COMPARISON:
    % A real utility sizes a fixed bank once, against a representative
    % (typically average / typical-day) loading condition, and then leaves
    % it energized. Sizing it against the PEAK hour instead -- with perfect
    % knowledge of the worst condition -- produces an idealized fixed bank
    % that does not exist in the field, and makes Case C's advantage look
    % artificially small: you would be comparing dynamic dispatch against
    % a fixed setting that was handed the answer in advance.
    %
    % cfg.fixedSizingPoint controls this:
    %   'average' (default) -- size at the interval whose total load is
    %                          closest to the daily mean. Realistic.
    %   'peak'              -- size at the peak interval. The idealized
    %                          best case for a fixed bank; use it if you
    %                          specifically want to show that dispatch
    %                          still competes even against that.
    vp('=== Step 6: Running Case B (fixed capacitor, energized 24/7) ===\n');
    if strcmpi(cfg.fixedSizingPoint, 'peak')
        t_fixed = t_peak;
    else
        [~, t_fixed] = min(abs(totalP - mean(totalP)));
    end
    Pf_size = Pmat(t_fixed,:)';
    Qf_size = Qmat(t_fixed,:)';
    kFixed = size_fixed_bank(topo, Pf_size, Qf_size, candidates, Ncap, ...
        cfg.Qstep, cfg.Vmin, cfg.Vmax, cfg.lam_v);
    capFixed = zeros(N,1);
    capFixed(candidates) = kFixed(candidates) * cfg.Qstep;
    vp('  Fixed bank sized at the ''%s'' operating point (hour %d, %.1f kW): %d kVAr installed\n', ...
        cfg.fixedSizingPoint, t_fixed-1, totalP(t_fixed), sum(capFixed));
    PlossB = zeros(T,1); VminB = zeros(T,1); VmagB = zeros(T,N);
    for t = 1:T
        [Vf, ~, Plf] = bfs_loadflow(topo, Pmat(t,:)', Qmat(t,:)', capFixed);
        PlossB(t) = Plf; VminB(t) = min(Vf); VmagB(t,:) = Vf';
    end

    %% ---------------- Step 6c: Case C -- Proposed Dispatch (greedy baseline) ----------------
    vp('=== Step 6: Running Case C -- greedy baseline dispatch ===\n');
    tic;
    [Kgreedy, PlossC_g, VminC_g, VmagC_g, switchops_g, greedyInfo] = greedy_dispatch( ...
        topo, Pmat, Qmat, candidates, Ncap, cfg.Qstep, Vmin, Vmax, lam_v, lam_s, Smax);
    t_greedy = toc;
    vp('  Greedy dispatch done in %.1f s. Total switching ops: %d (max/bank: %d, Smax=%d)\n', ...
        t_greedy, sum(switchops_g), max(switchops_g), Smax);
    if greedyInfo.repaired
        vp('  NOTE: enforce_switch_limit had to trim the greedy schedule to stay within Smax.\n');
    end

    %% ---------------- Step 6d: Case C -- Proposed Dispatch (PSO refined) ----------------
    havePSO = false;
    if cfg.RUN_PSO
        vp('=== Step 6: Running Case C -- PSO/GA refined dispatch (seeded from greedy) ===\n');
        tic;
        [Kpso, PlossC_p, VminC_p, VmagC_p, switchops_p, psoInfo] = pso_dispatch( ...
            topo, Pmat, Qmat, candidates, Ncap, cfg.Qstep, Vmin, Vmax, lam_v, lam_s, Smax, Kgreedy, cfg.pso);
        t_pso = toc;
        havePSO = true;
        vp('  Method: %s\n', psoInfo.method);
        vp('  PSO dispatch done in %.1f s. Total switching ops: %d\n', t_pso, sum(switchops_p));
        vp('  Improved on greedy seed: %d  (seed cost=%.2f, final cost=%.2f)\n', ...
            psoInfo.improved_on_seed, psoInfo.fseed, psoInfo.fbest);
    else
        vp('(RUN_PSO = false -- skipping PSO/GA refinement, using greedy result for Case C)\n');
    end

    %% ---------------- Step 7: Daily Energy Loss & Reporting ----------------
    vp('\n=== Step 7: Daily Energy Loss & Validation ===\n');
    hoursVec = (0:T-1) * (24/T);   % correct interval spacing for any T, not just hourly
    E_A  = trapz(hoursVec, PlossA);
    E_B  = trapz(hoursVec, PlossB);
    E_Cg = trapz(hoursVec, PlossC_g);

    compliantA  = all(VminA  >= Vmin) && all(max(VmagA, [],2) <= Vmax);
    compliantB  = all(VminB  >= Vmin) && all(max(VmagB, [],2) <= Vmax);
    compliantCg = all(VminC_g >= Vmin) && all(max(VmagC_g,[],2) <= Vmax);

    vp('Case A (uncompensated)      : daily loss = %.1f kWh, min voltage = %.4f p.u.\n', E_A, min(VminA));
    vp('Case B (fixed capacitor)    : daily loss = %.1f kWh, min voltage = %.4f p.u., max voltage = %.4f p.u.\n', ...
        E_B, min(VminB), max(VmagB(:)));
    vp('Case C (greedy baseline)    : daily loss = %.1f kWh, min voltage = %.4f p.u., reduction vs A = %.1f%%, vs B = %.2f%%\n', ...
        E_Cg, min(VminC_g), 100*(E_A-E_Cg)/E_A, 100*(E_B-E_Cg)/E_B);
    if havePSO
        E_Cp = trapz(hoursVec, PlossC_p);
        compliantCp = all(VminC_p >= Vmin) && all(max(VmagC_p,[],2) <= Vmax);
        vp('Case C (PSO/GA refined)     : daily loss = %.1f kWh, min voltage = %.4f p.u., reduction vs A = %.1f%%, vs B = %.2f%%\n', ...
            E_Cp, min(VminC_p), 100*(E_A-E_Cp)/E_A, 100*(E_B-E_Cp)/E_B);
        vp('PSO improvement over greedy : %.2f%%\n', 100*(E_Cg-E_Cp)/E_Cg);
    end

    vp('\nVoltage-band [%.2f, %.2f] compliance -- A: %d, B: %d, C(greedy): %d\n', ...
        Vmin, Vmax, compliantA, compliantB, compliantCg);
    vp('\nMax switching operations per bank (greedy): %d  (hard cap Smax=%d)\n', max(switchops_g), Smax);
    if havePSO
        vp('Max switching operations per bank (PSO)   : %d  (hard cap Smax=%d)\n', max(switchops_p), Smax);
    end

    %% ---------------- Plots ----------------
    if cfg.plots
        results_for_plot = struct();
        results_for_plot.T = T; results_for_plot.hoursVec = hoursVec;
        results_for_plot.VmagA = VmagA; results_for_plot.VmagB = VmagB; results_for_plot.VmagC = VmagC_g;
        results_for_plot.PlossA = PlossA; results_for_plot.PlossB = PlossB; results_for_plot.PlossC = PlossC_g;
        results_for_plot.switch_ops = switchops_g;
        results_for_plot.candidates = candidates;
        results_for_plot.Qstep = cfg.Qstep;
        results_for_plot.Ncap = Ncap;
        results_for_plot.Smax = Smax;
        results_for_plot.Vmin = Vmin; results_for_plot.Vmax = Vmax;
        results_for_plot.dispatchLabel = 'Greedy Dispatch';
        if havePSO && isfield(cfg,'plotPSO') && cfg.plotPSO
            results_for_plot.VmagC = VmagC_p;
            results_for_plot.PlossC = PlossC_p;
            results_for_plot.switch_ops = switchops_p;
            results_for_plot.dispatchLabel = 'PSO/GA Dispatch';
        end
        plot_results(results_for_plot);
    end
    vp('\n=== Done. ===\n');

    %% ---------------- Assemble results struct ----------------
    results = struct();
    results.cfg = cfg;

    results.system.N        = N;
    results.system.Vbase    = Vbase;
    results.system.Sbase    = Sbase;
    results.system.Pd       = Pd;
    results.system.Qd       = Qd;
    results.system.totalP   = sum(Pd);
    results.system.totalQ   = sum(Qd);
    results.system.bus_class = bus_class;

    results.profile.Pmat = Pmat;
    results.profile.Qmat = Qmat;
    results.profile.hours = hoursVec;

    results.validation.converged = conv_nom;
    results.validation.iters     = iters_nom;
    results.validation.Ploss_kW  = Ploss_nom;
    results.validation.minV      = minV_nom;
    results.validation.minBus    = minBus_nom;
    results.validation.passed    = valPassed;

    results.sensitivity.t_peak      = t_peak;
    results.sensitivity.peakHour    = t_peak - 1;
    results.sensitivity.Ploss_peak  = Ploss_peak;
    results.sensitivity.LSF         = LSF;
    results.sensitivity.VSI         = VSI;
    results.sensitivity.Pcum        = Pcum;
    results.sensitivity.Qcum        = Qcum;

    results.sizing.candidates = candidates;
    results.sizing.Ncap       = Ncap;
    results.sizing.Qstep      = cfg.Qstep;
    results.sizing.budgetFrac = cfg.budgetFrac;
    results.sizing.info       = sizingInfo;

    results.caseA = pack_case(PlossA, VminA, VmagA, E_A, compliantA);

    results.caseB = pack_case(PlossB, VminB, VmagB, E_B, compliantB);
    results.caseB.capFixed = capFixed;

    results.caseC_greedy = pack_case(PlossC_g, VminC_g, VmagC_g, E_Cg, compliantCg);
    results.caseC_greedy.K          = Kgreedy;
    results.caseC_greedy.switch_ops = switchops_g;
    results.caseC_greedy.maxSwitch  = max(switchops_g);
    results.caseC_greedy.runtime_s  = t_greedy;
    results.caseC_greedy.info       = greedyInfo;

    if havePSO
        results.caseC_pso = pack_case(PlossC_p, VminC_p, VmagC_p, E_Cp, compliantCp);
        results.caseC_pso.K          = Kpso;
        results.caseC_pso.switch_ops = switchops_p;
        results.caseC_pso.maxSwitch  = max(switchops_p);
        results.caseC_pso.runtime_s  = t_pso;
        results.caseC_pso.info       = psoInfo;
        results.caseC = results.caseC_pso;      % reported Case C = refined
    else
        results.caseC = results.caseC_greedy;   % reported Case C = greedy
    end

    % Headline summary
    results.summary.E_A_kWh  = E_A;
    results.summary.E_B_kWh  = E_B;
    results.summary.E_Cg_kWh = E_Cg;
    results.summary.reduction_greedy_vs_A_pct = 100*(E_A - E_Cg)/E_A;
    results.summary.reduction_greedy_vs_B_pct = 100*(E_B - E_Cg)/E_B;
    results.summary.compliant_A = compliantA;
    results.summary.compliant_B = compliantB;
    results.summary.compliant_C_greedy = compliantCg;
    if havePSO
        results.summary.E_Cp_kWh = E_Cp;
        results.summary.reduction_pso_vs_A_pct = 100*(E_A - E_Cp)/E_A;
        results.summary.reduction_pso_vs_B_pct = 100*(E_B - E_Cp)/E_B;
        results.summary.pso_vs_greedy_pct = 100*(E_Cg - E_Cp)/E_Cg;
        results.summary.compliant_C_pso = compliantCp;
    end
end


% ======================================================================
%                          local helper functions
% ======================================================================
function s = pack_case(Ploss, Vmin_t, Vmag, Edaily, compliant)
% Bundle the common per-case time-series into one struct.
    s.Ploss    = Ploss;              % [T x 1] kW at each interval
    s.Vmin     = Vmin_t;             % [T x 1] min bus voltage each interval
    s.Vmag     = Vmag;               % [T x N] full voltage profile
    s.Edaily   = Edaily;             % scalar kWh over the horizon
    s.minV     = min(Vmin_t);        % worst voltage over the horizon
    s.maxV     = max(Vmag(:));       % highest voltage over the horizon
    s.compliant = compliant;         % within [Vmin, Vmax] all intervals?
end


function cfg = merge_config(user)
% Fill any unspecified fields of the user's cfg with project defaults.
    cfg = default_config();
    if isempty(user) || ~isstruct(user); return; end
    fn = fieldnames(user);
    for i = 1:numel(fn)
        f = fn{i};
        if strcmp(f, 'pso') && isstruct(user.pso)
            pf = fieldnames(user.pso);
            for j = 1:numel(pf)
                cfg.pso.(pf{j}) = user.pso.(pf{j});
            end
        else
            cfg.(f) = user.(f);
        end
    end
end


function d = default_config()
% Validated best-configuration defaults -- see the header comment above
% for why these differ from the project's original Qstep=150/budgetFrac=0.75/lam_s=0.5.
    d.RUN_PSO = true;    % PSO is seeded from greedy and can never do worse, so run it by default
    d.T       = 24;
    d.loadProfile = 'dual';        % 'dual' (realistic, two daily peaks) or 'single'
    d.fixedSizingPoint = 'average'; % Case B sized at 'average' (realistic) or 'peak' (idealized)
    d.topK    = 8;
    d.bottomK = 8;
    d.Qstep   = 50;      % kVAr per step
    d.Nmax    = 15;      % max steps per site (=> max 750 kVAr per site)
    d.budgetFrac = 1.0;  % total installed kVAr as a fraction of feeder total Q
    d.Vmin    = 0.95;
    d.Vmax    = 1.05;
    d.lam_v   = 1e6;     % strongly penalize any voltage violation
    d.lam_s   = 0.05;    % base switching-penalty weight (escalates per-bank in greedy)
    d.Smax    = 12;      % hard daily switching-operation cap per bank
    d.plots   = true;
    d.plotPSO = false;   % if RUN_PSO, plot PSO's profile instead of greedy's
    d.verbose = true;
    d.pso.SwarmSize     = 40;
    d.pso.MaxIterations = 60;
end


function fprintf_if(flag, varargin)
% fprintf gated by the verbose flag, so main() can run silently.
    if flag
        fprintf(varargin{:});
    end
end
