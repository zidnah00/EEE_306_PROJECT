function [K, Ploss_t, Vmin_t, Vmag_all, switch_ops, info] = pso_dispatch( ...
    topo, Pmat, Qmat, candidates, Ncap, Qstep, Vmin, Vmax, lam_v, lam_s, Smax, Kseed, opts)
% PSO_DISPATCH  Refined online-stage dispatch (proposal Section 5.3,
%   second bullet). Treats the FULL T x M step-count matrix as a single
%   decision variable and evolves it with Particle Swarm Optimization,
%   correctly capturing the switching-penalty coupling between
%   consecutive intervals (which the greedy method only approximates one
%   interval at a time).
%
%   SEEDED FROM GREEDY, GUARANTEED NOT TO LOSE TO IT: one particle of the
%   initial swarm is seeded directly with the greedy schedule (Kseed),
%   converted back to the flattened decision-variable form. Since the
%   swarm can only ever improve on its best member, and the seed itself is
%   a valid, switching-feasible starting point with a known cost, PSO's
%   reported result is guaranteed to be at least as good as greedy's --
%   info.improved_on_seed tells you whether it actually found something
%   better (previously, random initialization could let PSO converge to
%   something WORSE than the simple baseline, which made "the sophisticated
%   algorithm" look broken in a comparison table for no good reason).
%
%   Uses MATLAB's built-in particleswarm() from the Global Optimization
%   Toolbox if available; automatically falls back to a small
%   self-contained PSO implementation (no toolbox dependency) if not.
%
%   INPUTS
%     topo, Pmat, Qmat, candidates, Ncap, Qstep, Vmin, Vmax, lam_v : as
%                  elsewhere in this project
%     lam_s      : base switching-penalty weight (scalar; PSO's fitness
%                  function uses the flat form, since the escalating
%                  per-bank pricing in greedy_dispatch is a SEARCH aid for
%                  a myopic hour-by-hour method -- PSO already reasons
%                  about the whole horizon jointly, so it doesn't need it)
%     Smax       : maximum switching operations per bank over the horizon
%                  -- every candidate schedule PSO evaluates is routed
%                  through enforce_switch_limit before being scored, so
%                  the swarm can never be rewarded for an infeasible schedule
%     Kseed      : [T x N] a switching-feasible schedule to seed the swarm
%                  with (normally greedy_dispatch's output K)
%     opts       : opts.SwarmSize (default 40), opts.MaxIterations (default 60)
%
%   OUTPUTS
%     K          : [T x N] final switching-feasible schedule
%     Ploss_t, Vmin_t, Vmag_all, switch_ops : from evaluate_schedule on K
%     info.method            : which solver actually ran (string)
%     info.fbest             : best objective value found
%     info.fseed             : the seed's (greedy's) objective value, for comparison
%     info.improved_on_seed  : true if PSO beat the greedy seed
%
%   NOTE ON RUNTIME: nvars = T*M. With default swarm size/iterations this
%   is SwarmSize*MaxIterations evaluations, each running T BFS solves --
%   well under a minute on a normal laptop for this problem size.

    if nargin < 13 || isempty(opts); opts = struct(); end
    if ~isfield(opts, 'SwarmSize');     opts.SwarmSize = 40;     end
    if ~isfield(opts, 'MaxIterations'); opts.MaxIterations = 60; end

    [T, N] = size(Pmat);
    M = numel(candidates);
    nvars = T * M;

    lb = zeros(nvars, 1);
    ub = zeros(nvars, 1);
    for ci = 1:M
        ub((ci-1)*T + 1 : ci*T) = Ncap(candidates(ci));
    end

    % Flatten Kseed (T x N, full bus indexing) into the T*M decision vector
    % ordering used here (column ci = candidate ci across all T hours).
    xseed = zeros(nvars, 1);
    for ci = 1:M
        c = candidates(ci);
        xseed((ci-1)*T + 1 : ci*T) = Kseed(:, c);
    end

    fitnessfcn = @(x) full_horizon_cost(x, topo, Pmat, Qmat, candidates, ...
        Qstep, Vmin, Vmax, lam_v, lam_s, Smax, T, M);

    fseed = fitnessfcn(xseed');

    use_toolbox = (exist('particleswarm', 'file') == 2);

    if use_toolbox
        pso_opts = optimoptions('particleswarm', ...
            'SwarmSize', opts.SwarmSize, ...
            'MaxIterations', opts.MaxIterations, ...
            'InitialSwarmMatrix', xseed', ...
            'Display', 'iter');
        [xbest, fbest] = particleswarm(fitnessfcn, nvars, lb, ub, pso_opts);
        info.method = 'particleswarm() -- Global Optimization Toolbox';
    else
        [xbest, fbest] = custom_pso(fitnessfcn, nvars, lb, ub, ...
            opts.SwarmSize, opts.MaxIterations, xseed);
        info.method = 'custom PSO fallback -- no toolbox dependency';
    end

    % Guarantee against a worse-than-seed result regardless of what the
    % optimizer returned (defends against toolbox quirks or an unlucky
    % swarm collapse in the fallback path).
    if fseed <= fbest
        xbest = xseed;
        fbest = fseed;
    end

    info.fbest            = fbest;
    info.fseed            = fseed;
    info.improved_on_seed = fbest < fseed - 1e-6;

    Kmat = round(reshape(xbest(:), T, M));
    Kraw = zeros(T, N);
    for ci = 1:M
        c = candidates(ci);
        col = max(0, min(Kmat(:,ci), Ncap(c)));
        Kraw(:,c) = col;
    end

    % Unconditional feasibility guarantee, same as greedy_dispatch.
    [K, repaired, ~] = enforce_switch_limit(Kraw, candidates, Smax);
    info.repaired = repaired;
    info.Smax     = Smax;

    [~, Ploss_t, Vmin_t, ~, Vmag_all, switch_ops] = evaluate_schedule( ...
        topo, Pmat, Qmat, K, candidates, Qstep, Vmin, Vmax, lam_v, lam_s);
end


function cost = full_horizon_cost(x, topo, Pmat, Qmat, candidates, Qstep, Vmin, Vmax, lam_v, lam_s, Smax, T, M)
% Local helper: evaluates the TOTAL horizon cost sum_t F(t) for one
% candidate solution x (a flattened T*M step-count matrix). The schedule
% is routed through enforce_switch_limit BEFORE scoring, so a candidate
% that "cheats" the switching cap is scored on what it would actually be
% forced to do, not on what it asked for -- it cannot be rewarded for an
% infeasible schedule.
    N = topo.N;
    Kmat = round(reshape(x(:), T, M));
    Kraw = zeros(T, N);
    for ci = 1:M
        c = candidates(ci);
        Kraw(:,c) = max(0, Kmat(:,ci));
    end
    Kfeas = enforce_switch_limit(Kraw, candidates, Smax);
    cost = evaluate_schedule(topo, Pmat, Qmat, Kfeas, candidates, Qstep, Vmin, Vmax, lam_v, lam_s);
end


function [xbest, fbest] = custom_pso(fitnessfcn, nvars, lb, ub, swarmsize, maxiter, xseed)
% Local helper: minimal, self-contained PSO -- the fallback used when the
% Global Optimization Toolbox is unavailable. Standard inertia-weight PSO,
% no toolbox functions used, with one particle seeded from xseed.
    w = 0.7; c1 = 1.5; c2 = 1.5;

    X = repmat(lb', swarmsize, 1) + rand(swarmsize, nvars) .* repmat((ub-lb)', swarmsize, 1);
    X(1,:) = xseed';    % seed one particle with the greedy solution
    Vel = zeros(swarmsize, nvars);

    Pbest = X;
    Pbest_f = zeros(swarmsize, 1);
    for i = 1:swarmsize
        Pbest_f(i) = fitnessfcn(X(i,:));
    end
    [fbest, gi] = min(Pbest_f);
    Gbest = Pbest(gi,:);

    for it = 1:maxiter
        r1 = rand(swarmsize, nvars);
        r2 = rand(swarmsize, nvars);
        Vel = w*Vel + c1*r1.*(Pbest - X) + c2*r2.*(repmat(Gbest, swarmsize, 1) - X);
        X = X + Vel;
        X = max(min(X, repmat(ub', swarmsize, 1)), repmat(lb', swarmsize, 1));

        f = zeros(swarmsize, 1);
        for i = 1:swarmsize
            f(i) = fitnessfcn(X(i,:));
        end
        better = f < Pbest_f;
        Pbest(better,:) = X(better,:);
        Pbest_f(better) = f(better);

        [fbest_it, gi] = min(Pbest_f);
        if fbest_it < fbest
            fbest = fbest_it;
            Gbest = Pbest(gi,:);
        end
    end
    xbest = Gbest;
end
