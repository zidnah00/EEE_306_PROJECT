function [K, Ploss_t, Vmin_t, Vmag_all, switch_ops, info] = greedy_dispatch( ...
    topo, Pmat, Qmat, candidates, Ncap, Qstep, Vmin, Vmax, lam_v, lam_s_base, Smax)
% GREEDY_DISPATCH  Baseline online-stage dispatch (proposal Section 5.3,
%   first bullet). For each interval, starting from the previous
%   interval's step settings, add or remove one step at a time at
%   whichever candidate site improves F(t) the most, until no single step
%   change improves it further.
%
%   TWO THINGS CHANGED FROM A PLAIN GREEDY SEARCH, BOTH TIED TO Smax:
%
%   1) A move is only ever CONSIDERED if the resulting displacement from
%      this bank's setting at the previous interval does not exceed its
%      remaining daily switching allowance. This is checked live, at the
%      moment of the decision -- greedy will not even try a move it can't
%      afford, rather than discovering the violation afterwards.
%
%   2) The switching price (lam_s) charged to a bank ESCALATES as it uses
%      up its daily allowance: a bank with plenty of switches left is
%      cheap to move, a bank close to its limit gets increasingly
%      expensive, via dispatch_objective's per-bank (vector) lam_s
%      support. This steers the search away from over-using a bank's
%      budget early in the day, before it becomes a hard block later.
%
%   Whatever falls out of this search is still passed through
%   enforce_switch_limit() as an unconditional safety net -- (1) and (2)
%   shape the search well, but the hard guarantee comes from that
%   function, not from how well lam_s was tuned.
%
%   INPUTS
%     topo       : struct from build_topology()
%     Pmat, Qmat : [T x N] time-varying load matrices from build_load_profile()
%     candidates : vector of candidate bus numbers from size_capacitors()
%     Ncap       : [N x 1] step-count upper limit per bus
%     Qstep      : capacitor step size (kVAr)
%     Vmin, Vmax : statutory voltage band (p.u.)
%     lam_v      : voltage-violation penalty weight
%     lam_s_base : base switching-penalty weight before escalation
%     Smax       : maximum switching operations allowed per bank over the
%                  whole horizon (e.g. 12)
%
%   OUTPUTS
%     K          : [T x N] step-count schedule k_i(t), GUARANTEED
%                  switching-feasible (routed through enforce_switch_limit)
%     Ploss_t    : [T x 1] total loss (kW) at each interval, from
%                  evaluate_schedule on the final, repaired K
%     Vmin_t     : [T x 1] minimum bus voltage (p.u.) at each interval
%     Vmag_all   : [T x N] full voltage profile at each interval
%     switch_ops : [N x 1] total switching operations per bus (<= Smax)
%     info       : struct with .repaired (bool, did enforce_switch_limit
%                  actually have to trim anything) and .Smax

    [T, N] = size(Pmat);
    M = numel(candidates);

    Kraw = zeros(T, N);
    remaining = Smax * ones(N,1);   % daily switching allowance left, per bus
    k_prev = zeros(N,1);

    for t = 1:T
        Pd = Pmat(t,:)';
        Qd = Qmat(t,:)';

        % Escalating per-bank price: cheap while allowance is plentiful,
        % up to 6x lam_s_base as a bank approaches its daily limit.
        lam_s_vec = zeros(N,1);
        for ci = 1:M
            c = candidates(ci);
            usedFrac = 1 - remaining(c)/max(Smax,1);
            lam_s_vec(c) = lam_s_base * (1 + 5*usedFrac);
        end

        best_k = k_prev;
        cap = zeros(N,1);
        cap(candidates) = best_k(candidates) * Qstep;
        [Vb, ~, Plb] = bfs_loadflow(topo, Pd, Qd, cap);
        best_F = dispatch_objective(Plb, Vb, best_k, k_prev, Vmin, Vmax, lam_v, lam_s_vec);

        improved = true;
        iter = 0;
        while improved && iter < 200
            improved = false;
            iter = iter + 1;
            for ci = 1:M
                c = candidates(ci);
                for delta = [-1, 1]
                    k_trial = best_k;
                    k_trial(c) = k_trial(c) + delta;
                    if k_trial(c) < 0 || k_trial(c) > Ncap(c)
                        continue;
                    end
                    % Reject at decision time if this bank can't afford the
                    % resulting displacement from its previous setting.
                    if abs(k_trial(c) - k_prev(c)) > remaining(c)
                        continue;
                    end
                    capT = zeros(N,1);
                    capT(candidates) = k_trial(candidates) * Qstep;
                    [Vt, ~, Plt] = bfs_loadflow(topo, Pd, Qd, capT);
                    Ft = dispatch_objective(Plt, Vt, k_trial, k_prev, Vmin, Vmax, lam_v, lam_s_vec);
                    if Ft < best_F - 1e-9
                        best_F = Ft;
                        best_k = k_trial;
                        improved = true;
                    end
                end
            end
        end

        Kraw(t,:) = best_k';
        remaining(candidates) = remaining(candidates) - abs(best_k(candidates) - k_prev(candidates));
        k_prev = best_k;
    end

    % Unconditional safety net: guarantee feasibility regardless of how
    % well the live rejection/pricing above worked.
    [K, repaired, ~] = enforce_switch_limit(Kraw, candidates, Smax);

    % Report everything from the ONE shared evaluator so these numbers
    % can never disagree with what pso_dispatch or the plots show.
    [~, Ploss_t, Vmin_t, ~, Vmag_all, switch_ops] = evaluate_schedule( ...
        topo, Pmat, Qmat, K, candidates, Qstep, Vmin, Vmax, lam_v, lam_s_base);

    info.repaired = repaired;
    info.Smax     = Smax;
end
