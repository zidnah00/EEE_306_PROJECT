function kFixed = size_fixed_bank(topo, Pd_kW, Qd_kVAr, candidates, Ncap, Qstep, Vmin, Vmax, lam_v)
% SIZE_FIXED_BANK  Sizes the single, non-time-varying capacitor setting
%   used for Case B, by running one greedy step-improvement pass at the
%   supplied operating point and stopping once no further step change
%   reduces the objective.
%
%   This is the offline "install it and leave it" decision, so there is no
%   switching-penalty term and no notion of a previous interval -- only
%   loss plus voltage-violation penalty at that one operating point.
%
%   WHICH OPERATING POINT YOU PASS IN MATTERS A LOT for the fairness of
%   the Case B vs. Case C comparison (see main.m's Step 6b comment):
%   sizing at the daily-average condition reflects how a fixed bank is
%   actually specified in practice; sizing at the peak condition gives an
%   idealized fixed bank that was effectively told the worst case in
%   advance, and understates what dynamic dispatch is worth.
%
%   INPUTS
%     topo       : struct from build_topology()
%     Pd_kW, Qd_kVAr : [N x 1] loads AT THE SIZING OPERATING POINT
%     candidates : candidate bus vector from size_capacitors()
%     Ncap       : [N x 1] per-bus step-count upper limit
%     Qstep      : capacitor step size (kVAr)
%     Vmin, Vmax : statutory voltage band (p.u.)
%     lam_v      : voltage-violation penalty weight
%
%   OUTPUT
%     kFixed : [N x 1] step-count vector to hold constant for the whole
%              horizon (0 for non-candidate buses)

    N = topo.N;
    M = numel(candidates);

    best_k = zeros(N,1);
    cap = zeros(N,1);
    [Vb, ~, Plb] = bfs_loadflow(topo, Pd_kW, Qd_kVAr, cap);
    best_F = dispatch_objective(Plb, Vb, best_k, best_k, Vmin, Vmax, lam_v, 0);

    improved = true;
    iter = 0;
    while improved && iter < 200
        improved = false;
        iter = iter + 1;
        for ci = 1:M
            c = candidates(ci);
            for delta = [-1, 1]
                k_trial = best_k;
                k_trial(c) = k_trial(c) + delta;
                if k_trial(c) < 0 || k_trial(c) > Ncap(c)
                    continue;
                end
                capT = zeros(N,1);
                capT(candidates) = k_trial(candidates) * Qstep;
                [Vt, ~, Plt] = bfs_loadflow(topo, Pd_kW, Qd_kVAr, capT);
                Ft = dispatch_objective(Plt, Vt, k_trial, k_trial, Vmin, Vmax, lam_v, 0);
                if Ft < best_F - 1e-9
                    best_F = Ft;
                    best_k = k_trial;
                    improved = true;
                end
            end
        end
    end

    kFixed = best_k;
end
