function plot_results(r)
% PLOT_RESULTS  Produces the plots required by proposal Step 7, drawn
%   PURELY from the fields of the results struct r passed in by main.m --
%   no recomputation happens here, so a figure can never disagree with the
%   printed console numbers or the values in the returned results struct.
%
%   INPUT  r (struct), fields:
%     .T, .hoursVec           horizon length and the hour-of-day x-axis
%     .VmagA, .VmagB, .VmagC  [T x N] voltage profiles for Cases A/B/C
%     .PlossA, .PlossB, .PlossC  [T x 1] loss profiles for Cases A/B/C
%     .switch_ops             [N x 1] switching operations per bus (Case C)
%     .candidates             candidate bus vector
%     .Qstep, .Ncap           sizing info, for the reference note on plot 3
%     .Smax                   hard switching cap, drawn as a reference line
%     .Vmin, .Vmax            statutory voltage band, drawn as reference lines
%     .dispatchLabel          'Greedy Dispatch' or 'PSO/GA Dispatch' --
%                              whichever Case C is actually being plotted
%
%   Produces:
%     1) 24-hour voltage profile at the weakest bus, all 3 cases overlaid
%     2) Daily loss profile P_loss(t) for all 3 cases
%     3) Switching-operations bar chart per bank, vs. the actual Smax used
%     4) Bus voltage heatmap (all buses, all hours) for Case C

    hours = r.hoursVec;
    N = size(r.VmagA, 2);

    % Identify the weakest bus from Case A itself (don't hardcode "bus 18" --
    % that was true for the original candidate set, not necessarily this one).
    [~, weakBus] = min(min(r.VmagA, [], 1));

    % ---- Plot 1: Voltage profile at weakest bus, all cases ----
    figure('Name', 'Voltage Profile at Weakest Bus');
    plot(hours, r.VmagA(:,weakBus), '-o', 'LineWidth', 1.5, 'DisplayName', 'Case A: Uncompensated'); hold on;
    plot(hours, r.VmagB(:,weakBus), '-s', 'LineWidth', 1.5, 'DisplayName', 'Case B: Fixed Capacitor');
    plot(hours, r.VmagC(:,weakBus), '-^', 'LineWidth', 1.5, 'DisplayName', ['Case C: ' r.dispatchLabel]);
    yline(r.Vmax, '--r', sprintf('V_{max} = %.2f p.u.', r.Vmax));
    yline(r.Vmin, '--r', sprintf('V_{min} = %.2f p.u.', r.Vmin));
    xlabel('Hour of Day'); ylabel('Voltage Magnitude (p.u.)');
    title(sprintf('24-Hour Voltage Profile at Bus %d (weakest bus)', weakBus));
    legend('Location', 'best'); grid on;

    % ---- Plot 2: Daily loss profile, all cases ----
    figure('Name', 'Daily Loss Profile');
    plot(hours, r.PlossA, '-o', 'LineWidth', 1.5, 'DisplayName', 'Case A: Uncompensated'); hold on;
    plot(hours, r.PlossB, '-s', 'LineWidth', 1.5, 'DisplayName', 'Case B: Fixed Capacitor');
    plot(hours, r.PlossC, '-^', 'LineWidth', 1.5, 'DisplayName', ['Case C: ' r.dispatchLabel]);
    xlabel('Hour of Day'); ylabel('Total System Loss (kW)');
    title('24-Hour Loss Profile Comparison');
    legend('Location', 'best'); grid on;

    % ---- Plot 3: Switching operations per bank ----
    figure('Name', 'Switching Operations per Bank');
    ops = r.switch_ops(r.candidates);
    bar(r.candidates, ops);
    hold on;
    yline(r.Smax, '--r', sprintf('S_{max} = %d ops/day (enforced)', r.Smax));
    ylim([0, max(r.Smax, max(ops))*1.15]);
    xlabel('Candidate Bus'); ylabel('Switching Operations (per day)');
    title(sprintf('Daily Switching Operations per Bank -- Case C: %s', r.dispatchLabel));
    grid on;

    % ---- Plot 4: full voltage heatmap for Case C ----
    figure('Name', 'Voltage Heatmap - Case C');
    imagesc(hours, 1:N, r.VmagC');
    set(gca, 'YDir', 'normal');
    colorbar; caxis([min(r.VmagA(:))*0.995, 1.05]); %#ok<CAXIS>
    xlabel('Hour of Day'); ylabel('Bus Number');
    title(['Bus Voltage Over the Horizon -- Case C: ' r.dispatchLabel]);

    fprintf('\nPlots generated: (1) Voltage profile, (2) Loss profile, (3) Switching ops, (4) Voltage heatmap\n');
    fprintf('Candidate sizing reference: Qstep = %d kVAr, Ncap per site = %s\n', ...
        r.Qstep, mat2str(r.Ncap(r.candidates)'));
end
