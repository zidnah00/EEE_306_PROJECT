function [LSF, VSI, Pcum, Qcum] = compute_LSF_VSI(topo, Vmag, Pd_kW, Qd_kVAr)
% COMPUTE_LSF_VSI  Loss Sensitivity Factor and Voltage Stability Index
%   at every bus, evaluated at a single operating point (normally peak
%   load) per proposal Step 3.
%
%   IMPORTANT: both LSF and VSI use the CUMULATIVE downstream real/
%   reactive power flowing THROUGH the branch feeding each bus — i.e.
%   the bus's own demand plus everything downstream of it — not just
%   that bus's own local load. This is the standard formulation (it's
%   also what the branch "sees" electrically) and it matters a lot for
%   sizing in Step 4: buses near the substation carrying large
%   downstream flow are correctly favoured over buses with a small
%   local load but nothing behind them.
%
%   INPUTS
%     topo    : struct from build_topology()
%     Vmag    : [N x 1] voltage magnitudes (p.u.) at the evaluation point
%               (normally from bfs_loadflow() run at peak load)
%     Pd_kW, Qd_kVAr : [N x 1] bus loads (kW, kVAr) AT THE SAME operating
%               point used to obtain Vmag (i.e. the peak-load P/Q vectors)
%
%   OUTPUTS
%     LSF  : [N x 1] Loss Sensitivity Factor, LSF_i = 2*R_i*Qcum_i / |V_i|^2
%     VSI  : [N x 1] Voltage Stability Index (Chakravorty & Das form);
%            LOWER VSI = closer to voltage collapse = higher priority
%     Pcum, Qcum : [N x 1] cumulative downstream P/Q (kW, kVAr) through
%            the branch feeding each bus — also needed by size_capacitors()

    N = topo.N;
    Pcum = Pd_kW(:);
    Qcum = Qd_kVAr(:);
    Pcum(1) = 0;
    Qcum(1) = 0;

    % Sum each bus's cumulative load up into its parent, processing
    % leaves-before-parents (rev_order) so a bus's own cumulative total
    % is finalized (own load + all descendants already folded in)
    % before it is added into ITS parent's total.
    for idx = 1:N
        u = topo.rev_order(idx);
        if u == 1
            continue;
        end
        p = topo.parent(u);
        Pcum(p) = Pcum(p) + Pcum(u);
        Qcum(p) = Qcum(p) + Qcum(u);
    end

    LSF = zeros(N,1);
    VSI = zeros(N,1);
    Zbase = topo.Zbase;

    for u = 2:N
        r_ohm = topo.Rpu(u) * Zbase;
        x_ohm = topo.Xpu(u) * Zbase;

        LSF(u) = 2 * r_ohm * Qcum(u) / Vmag(u)^2;

        p  = topo.parent(u);
        Vs = Vmag(p);
        Pb_pu = Pcum(u) * 1e3 / topo.Sbase;
        Qb_pu = Qcum(u) * 1e3 / topo.Sbase;
        rpu = topo.Rpu(u);
        xpu = topo.Xpu(u);

        VSI(u) = Vs^4 - 4*(Pb_pu*xpu - Qb_pu*rpu)^2 - 4*(Pb_pu*rpu + Qb_pu*xpu)*Vs^2;
    end
end
