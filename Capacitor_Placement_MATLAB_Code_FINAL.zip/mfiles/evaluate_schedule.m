function [cost, Ploss_t, Vmin_t, Vmax_t, Vmag_all, switch_ops] = evaluate_schedule( ...
    topo, Pmat, Qmat, K, candidates, Qstep, Vmin, Vmax, lam_v, lam_s)
% EVALUATE_SCHEDULE  Turns a complete T x N step-count schedule into every
%   number anyone downstream needs (cost, per-interval loss/voltage, full
%   voltage profile, switching operations) -- IN ONE PLACE.
%
%   WHY THIS EXISTS: previously greedy_dispatch, pso_dispatch, and the
%   main script each re-implemented their own "replay this schedule
%   through the horizon and add it up" loop. Three copies of the same
%   logic is exactly how an optimizer's internal score and the reported
%   result quietly drift apart -- a formula fixed in one copy and
%   forgotten in another. Every caller in this project now goes through
%   this one function instead, so greedy, PSO, and the plots are
%   provably scored on the same objective and can never disagree.
%
%   INPUTS
%     topo       : struct from build_topology()
%     Pmat, Qmat : [T x N] load matrices from build_load_profile()
%     K          : [T x N] step-count schedule to evaluate (0 for
%                  non-candidate buses; typically already passed through
%                  enforce_switch_limit() before being handed here)
%     candidates : candidate bus vector
%     Qstep      : capacitor step size (kVAr)
%     Vmin, Vmax : statutory voltage band (p.u.)
%     lam_v      : voltage-violation penalty weight
%     lam_s      : switching penalty -- scalar (applied to every bank
%                  equally) OR [N x 1] vector (a per-bank price; see
%                  dispatch_objective.m)
%
%   OUTPUTS
%     cost       : scalar, sum_t F(t) over the whole horizon
%     Ploss_t    : [T x 1] total loss (kW) at each interval
%     Vmin_t     : [T x 1] minimum bus voltage (p.u.) at each interval
%     Vmax_t     : [T x 1] maximum bus voltage (p.u.) at each interval
%     Vmag_all   : [T x N] full voltage profile at each interval
%     switch_ops : [N x 1] total switching operations per bus over the
%                  whole horizon (k_i(0) = 0), 0 for non-candidates

    [T, N] = size(Pmat);

    Ploss_t  = zeros(T,1);
    Vmin_t   = zeros(T,1);
    Vmax_t   = zeros(T,1);
    Vmag_all = zeros(T,N);

    cost   = 0;
    k_prev = zeros(N,1);

    for t = 1:T
        k_t = zeros(N,1);
        k_t(candidates) = K(t,candidates);

        cap = zeros(N,1);
        cap(candidates) = k_t(candidates) * Qstep;

        [Vf, ~, Plf] = bfs_loadflow(topo, Pmat(t,:)', Qmat(t,:)', cap);

        Ploss_t(t)    = Plf;
        Vmin_t(t)     = min(Vf);
        Vmax_t(t)     = max(Vf);
        Vmag_all(t,:) = Vf';

        cost = cost + dispatch_objective(Plf, Vf, k_t, k_prev, Vmin, Vmax, lam_v, lam_s);
        k_prev = k_t;
    end

    switch_ops = zeros(N,1);
    prev = zeros(N,1);
    for t = 1:T
        switch_ops = switch_ops + abs(K(t,:)' - prev);
        prev = K(t,:)';
    end
end
