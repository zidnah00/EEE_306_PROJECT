function [Kfeas, changed, usedOps] = enforce_switch_limit(K, candidates, Smax)
% ENFORCE_SWITCH_LIMIT  Hard feasibility repair for the daily switching
%   cap. This is a genuine constraint, not a tuned penalty: it guarantees
%
%       sum_{t=1}^{T} |k_i(t) - k_i(t-1)|  <=  Smax     for every bank i
%                                                (k_i(0) = 0)
%
%   Whether lam_s in the objective function was tuned "enough" to
%   discourage over-switching is a matter of luck; this function makes the
%   limit true by construction, so anything that passes through it is
%   switching-feasible no matter how it was produced (greedy, PSO, or a
%   hand-edited schedule).
%
%   HOW IT WORKS: walks the horizon forward, hour by hour. Each bank has a
%   running "allowance" (Smax minus operations already used). If the
%   schedule asks for a bigger step change than the bank has allowance
%   left, the move is truncated to whatever it can still afford, and the
%   bank effectively freezes at that value once its allowance hits zero
%   for the rest of the horizon. It never invents extra operations beyond
%   what the input schedule asked for -- it only ever trims moves down.
%
%   INPUTS
%     K          : [T x N] step-count schedule (as produced by
%                  greedy_dispatch or pso_dispatch), 0 for non-candidates
%     candidates : vector of candidate bus numbers to enforce the limit on
%     Smax       : maximum switching operations allowed per bank over the
%                  whole horizon (e.g. 12)
%
%   OUTPUTS
%     Kfeas    : [T x N] the repaired, switching-feasible schedule
%     changed  : true if the limit was actually binding anywhere (i.e. the
%                input schedule needed trimming) -- worth reporting, since
%                it tells you whether Smax is a real constraint on your
%                results or just headroom
%     usedOps  : [N x 1] total switching operations actually used per bank
%                after repair (<= Smax for every candidate, 0 elsewhere)

    [T, N] = size(K);
    Kfeas  = K;
    usedOps = zeros(N,1);
    changed = false;

    prev = zeros(N,1);   % k_i(0) = 0, per the constraint definition above
    for t = 1:T
        for ci = 1:numel(candidates)
            c = candidates(ci);
            desired = K(t,c);
            delta   = desired - prev(c);
            if delta == 0
                continue;
            end
            allowance = Smax - usedOps(c);
            dirn      = sign(delta);
            n_move    = min(abs(delta), allowance);
            if n_move < abs(delta)
                changed = true;
            end
            newVal = prev(c) + dirn*n_move;
            Kfeas(t,c) = newVal;
            usedOps(c) = usedOps(c) + n_move;
        end
        prev = Kfeas(t,:)';
    end
end
