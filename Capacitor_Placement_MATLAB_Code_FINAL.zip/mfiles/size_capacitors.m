function [candidates, Ncap, info] = size_capacitors(topo, LSF, VSI, Qcum, ...
    topK, bottomK, Qstep, Nmax, budgetFrac)
% SIZE_CAPACITORS  Candidate bus selection (proposal Step 3) and discrete
%   capacitor sizing (Step 4), combined into one offline-stage call.
%
%   ------------------------------------------------------------------
%   WHY THIS IS NOT JUST  Q_i = min(Qcum_i, Qstep*Nmax)
%   ------------------------------------------------------------------
%   Qcum_i is the CUMULATIVE reactive flow through the branch feeding bus
%   i -- bus i's own load plus everything downstream of it. That is the
%   right quantity for RANKING a site (it is what the branch actually
%   carries), but it is the wrong quantity for SIZING several sites at
%   once, because candidate sites on the same lateral are nested: the
%   reactive flow through bus 6 also flows through bus 3 and bus 2. Sizing
%   each site independently to its own Qcum counts that same flow once per
%   site and grossly over-installs. On this feeder that error is large
%   enough to push light-load voltages above 1.05 p.u. purely as a sizing
%   artifact -- which then gets misread as a physics lesson about fixed
%   capacitors.
%
%   Two corrections are applied here:
%
%   1) EXCLUSIVE (non-overlapping) reactive flow.  For each candidate c,
%
%          Qexcl(c) = Qcum(c) - sum( Qcum(d) : d in nearest_downstream_candidates(c) )
%
%      i.e. the reactive flow that arises between c and the next candidate
%      site(s) below it, and is therefore c's own responsibility. Summed
%      over all candidates this telescopes to at most the feeder's total
%      reactive demand, so no kVAr is ever allocated twice.
%
%   2) A TOTAL kVAr BUDGET.  Installed capacity is capped at
%      budgetFrac * (total feeder reactive demand at the sizing operating
%      point). Sites are funded in priority order until the budget runs
%      out. This reflects the real engineering constraint (a compensation
%      target / capital limit) and keeps the fleet physically sensible.
%
%   ------------------------------------------------------------------
%   INPUTS
%     topo      : struct from build_topology()  (needed for the tree walk)
%     LSF, VSI  : [N x 1] outputs of compute_LSF_VSI()
%     Qcum      : [N x 1] cumulative downstream reactive flow (kVAr) from
%                 compute_LSF_VSI(). Qcum(1) is the feeder total.
%     topK      : how many top-LSF buses to include (e.g. 8)
%     bottomK   : how many bottom-VSI buses to include (e.g. 8)
%     Qstep     : capacitor step size (kVAr). NOTE: 150 kVAr is too coarse
%                 on this feeder -- once the exclusive-flow correction is
%                 applied, most pooled buses' exclusive share falls below
%                 150 kVAr and gets floored to zero no matter the budget.
%                 50 kVAr recovers a much richer, genuinely non-overlapping
%                 candidate set (validated: 8 funded sites vs. 3).
%     Nmax      : maximum steps allowed per site (bank cap), e.g. 15
%                 (so max bank size per site = Nmax*Qstep = 750 kVAr)
%     budgetFrac: total installed kVAr as a fraction of the feeder's total
%                 reactive demand (default 0.75). 1.0 = install as much of
%                 the (already non-overlapping) exclusive demand as the
%                 per-site Nmax ceiling allows; 0 = no capacitors at all.
%
%   OUTPUTS
%     candidates : sorted vector of FUNDED candidate bus numbers. Sites
%                  that end up with zero steps are dropped -- they are not
%                  useful decision variables and would only inflate the
%                  dispatch search space.
%     Ncap       : [N x 1] per-site step-count upper limit N_i
%                  (0 for every non-funded bus)
%     info       : struct documenting the sizing decision, for your report
%       .pool        all buses in union(top-LSF, bottom-VSI) before funding
%       .Qexcl       [N x 1] exclusive reactive flow used for sizing
%       .Qcum_total  feeder total reactive demand (kVAr)
%       .budget      total kVAr budget applied
%       .installed   total kVAr actually installed
%       .rankLSF, .rankVSI, .priority  ranking detail per pooled bus
%       .table       [nPooled x 6] = [bus, rankLSF, rankVSI, Qcum, Qexcl, kVAr]

    N     = numel(LSF);
    buses = (2:N)';

    if nargin < 9 || isempty(budgetFrac); budgetFrac = 0.75; end

    % ---------------- Step 3: candidate pool ----------------
    [~, idxLSF] = sort(LSF(buses), 'descend');
    topLSF = buses(idxLSF(1:min(topK, numel(buses))));

    [~, idxVSI] = sort(VSI(buses), 'ascend');    % LOW VSI = weakest
    bottomVSI = buses(idxVSI(1:min(bottomK, numel(buses))));

    pool = sort(union(topLSF, bottomVSI));
    pool = pool(:);
    nP   = numel(pool);

    % ---------------- Priority: Borda count of the two rankings ----------------
    % rank 1 = most attractive on that index. A bus that is not in the
    % top/bottom list of an index is given a rank just past the end of that
    % list, so being strong on ONE index is enough to be funded early, and
    % being strong on BOTH ranks it first.
    rankLSF = zeros(nP,1);
    rankVSI = zeros(nP,1);
    for i = 1:nP
        rL = find(topLSF    == pool(i), 1);
        rV = find(bottomVSI == pool(i), 1);
        if isempty(rL); rL = numel(topLSF)    + 1; end
        if isempty(rV); rV = numel(bottomVSI) + 1; end
        rankLSF(i) = rL;
        rankVSI(i) = rV;
    end
    priority = rankLSF + rankVSI;                 % lower = funded earlier
    [~, ordP] = sortrows([priority, rankLSF, rankVSI]);
    fundOrder = pool(ordP);

    % ---------------- Exclusive (non-overlapping) reactive flow ----------------
    isPool = false(N,1);
    isPool(pool) = true;

    Qexcl = zeros(N,1);
    for i = 1:nP
        c = pool(i);
        q = Qcum(c);
        stack = topo.children{c};
        while ~isempty(stack)
            u = stack(end);
            stack(end) = [];
            if isPool(u)
                q = q - Qcum(u);          % that flow is u's responsibility
            else
                stack = [stack, topo.children{u}]; %#ok<AGROW>
            end
        end
        Qexcl(c) = max(0, q);
    end

    % ---------------- Step 4: discrete sizing under a total budget ----------------
    Qcum_total = Qcum(1);                 % compute_LSF_VSI folds everything into bus 1
    budget     = budgetFrac * Qcum_total;
    remaining  = budget;

    Ncap = zeros(N,1);
    for i = 1:numel(fundOrder)
        c = fundOrder(i);
        qcap  = min([Qexcl(c), Qstep*Nmax, remaining]);
        steps = floor(qcap / Qstep);
        if steps > 0
            Ncap(c)   = steps;
            remaining = remaining - steps*Qstep;
        end
    end

    candidates = sort(find(Ncap > 0));
    candidates = candidates(:);

    % ---------------- Reporting ----------------
    info.pool       = pool;
    info.Qexcl      = Qexcl;
    info.Qcum_total = Qcum_total;
    info.budget     = budget;
    info.installed  = sum(Ncap) * Qstep;
    info.budgetFrac = budgetFrac;
    info.rankLSF    = rankLSF;
    info.rankVSI    = rankVSI;
    info.priority   = priority;
    info.fundOrder  = fundOrder;
    info.table      = [pool, rankLSF, rankVSI, Qcum(pool), Qexcl(pool), Ncap(pool)*Qstep];
end
