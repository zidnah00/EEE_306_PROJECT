function [Pmat, Qmat, bus_class, LFall] = build_load_profile(Pd, Qd, N, T, profileType)
% BUILD_LOAD_PROFILE  Generate a T-interval (default 24-hour) P/Q load
%   trajectory for every bus using per-class normalized load-factor
%   curves (per proposal Section 3.2).
%
%   INPUTS
%     Pd, Qd : [N x 1] nominal (peak) bus loads (kW, kVAr)
%     N      : number of buses
%     T      : number of time intervals (default 24 for 1-hour resolution;
%              use 96 for 15-minute resolution)
%     profileType : 'dual' (default) or 'single'
%       'dual'   -- residential and commercial classes each have TWO daily
%                   peaks (morning + evening for residential, two office-
%                   hours humps for commercial), industrial a daytime
%                   plateau. This is the more realistic shape, and it also
%                   matters for testing dispatch: a single well-sized
%                   fixed capacitor setting cannot be simultaneously
%                   correct for two structurally different peak
%                   conditions the way a smooth single-peak curve lets it
%                   get away with -- so this is the profile to use if you
%                   want to see dynamic dispatch's advantage over a fixed
%                   bank clearly, not just its advantage over no
%                   compensation at all.
%       'single' -- the original smooth single-peak curves (residential
%                   evening peak, commercial midday peak). Kept available
%                   for comparison / as the simpler case in a sensitivity
%                   study -- a fixed bank looks artificially competitive
%                   here specifically because there is only one peak to
%                   size it for.
%
%   OUTPUTS
%     Pmat, Qmat : [T x N] time-varying load matrices (kW, kVAr)
%     bus_class  : [N x 1] class code per bus (1=res, 2=com, 3=ind)
%     LFall      : [T x 3] the three normalized load-factor curves used
%
%   NOTE: the bus-to-class assignment below (buses 2-12 residential,
%   13-22 commercial, 23-33 industrial) is a reasonable illustrative
%   default consistent with the proposal's requirement to "assign each
%   bus to a load class" — adjust the ranges below if your team wants a
%   different assignment (e.g. based on actual feeder characteristics).

    if nargin < 4 || isempty(T)
        T = 24;
    end
    if nargin < 5 || isempty(profileType)
        profileType = 'dual';
    end
    hours = (0:T-1)' * (24/T);   % maps interval index to hour-of-day, 0-24

    if strcmpi(profileType, 'single')
        LF_res = min(max(0.4 + 0.6*exp(-((hours-19).^2)/18), 0.3), 1.0);
        LF_com = min(max(0.3 + 0.7*exp(-((hours-13).^2)/18), 0.25), 1.0);
        LF_ind = min(max(0.6 + 0.35*(hours>=8 & hours<=18), 0.5), 1.0);
    else
        % Dual-peak: residential morning + evening, commercial two
        % office-hours humps, industrial unchanged (already flat/plateau).
        LF_res = min(max(0.35 + 0.45*exp(-((hours-8).^2)/8) ...
                              + 0.50*exp(-((hours-19).^2)/10), 0.3), 1.0);
        LF_com = min(max(0.30 + 0.60*exp(-((hours-9).^2)/6) ...
                              + 0.50*exp(-((hours-18).^2)/10), 0.25), 1.0);
        LF_ind = min(max(0.5 + 0.45*(hours>=7 & hours<=18), 0.5), 1.0);
    end
    LFall  = [LF_res, LF_com, LF_ind];

    bus_class = 3*ones(N,1);   % default: industrial
    for b = 2:N
        if b <= 12
            bus_class(b) = 1;   % residential
        elseif b <= 22
            bus_class(b) = 2;   % commercial
        else
            bus_class(b) = 3;   % industrial
        end
    end

    Pmat = zeros(T,N);
    Qmat = zeros(T,N);
    for b = 2:N
        lf = LFall(:, bus_class(b));
        Pmat(:,b) = Pd(b) * lf;
        Qmat(:,b) = Qd(b) * lf;
    end
end
