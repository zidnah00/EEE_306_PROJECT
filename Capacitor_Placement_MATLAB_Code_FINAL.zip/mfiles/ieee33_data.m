function [branch, Pd, Qd, Vbase, Sbase] = ieee33_data()
% IEEE33_DATA  Line and load data for the IEEE 33-bus radial distribution
%   test system (Baran & Wu, 1989), as published in MATPOWER's case33bw.
%
%   OUTPUTS
%     branch : [Nbranch x 4] = [fromBus, toBus, R(ohm), X(ohm)]
%              32 branches forming the radial tree (5 optional tie
%              switches from the original case33bw are NOT included,
%              since this project uses the base radial topology only).
%     Pd, Qd : [33 x 1] nominal real/reactive load at each bus (kW, kVAr).
%              Bus 1 is the substation (slack), Pd(1)=Qd(1)=0.
%     Vbase  : line voltage base (V) = 12.66 kV
%     Sbase  : system MVA base (VA) = 100 MVA (MATPOWER convention;
%              only used internally to per-unitize impedances)
%
%   VALIDATION: running bfs_loadflow on these nominal loads with no
%   capacitors must return total P loss = 202.677 kW and minimum
%   voltage = 0.9131 p.u. at bus 18 — the standard published benchmark
%   for this test system. This has been independently verified.

    branch = [
        1   2   0.0922  0.0470;
        2   3   0.4930  0.2511;
        3   4   0.3660  0.1864;
        4   5   0.3811  0.1941;
        5   6   0.8190  0.7070;
        6   7   0.1872  0.6188;
        7   8   0.7114  0.2351;
        8   9   1.0300  0.7400;
        9   10  1.0440  0.7400;
        10  11  0.1966  0.0650;
        11  12  0.3744  0.1238;
        12  13  1.4680  1.1550;
        13  14  0.5416  0.7129;
        14  15  0.5910  0.5260;
        15  16  0.7463  0.5450;
        16  17  1.2890  1.7210;
        17  18  0.7320  0.5740;
        2   19  0.1640  0.1565;
        19  20  1.5042  1.3554;
        20  21  0.4095  0.4784;
        21  22  0.7089  0.9373;
        3   23  0.4512  0.3083;
        23  24  0.8980  0.7091;
        24  25  0.8960  0.7011;
        6   26  0.2030  0.1034;
        26  27  0.2842  0.1447;
        27  28  1.0590  0.9337;
        28  29  0.8042  0.7006;
        29  30  0.5075  0.2585;
        30  31  0.9744  0.9630;
        31  32  0.3105  0.3619;
        32  33  0.3410  0.5302
    ];

    %        bus:  1    2    3    4    5    6    7    8    9   10   11   12   13   14   15   16   17   18   19   20   21   22   23   24   25   26   27   28   29   30   31   32   33
    Pd = [    0  100   90  120   60   60  200  200   60   60   45   60   60  120   60   60   60   90   90   90   90   90   90  420  420   60   60   60  120  200  150  210   60]';
    Qd = [    0   60   40   80   30   20  100  100   20   20   30   35   35   80   10   20   20   40   40   40   40   40   50  200  200   25   25   20   70  600   70  100   40]';

    Vbase = 12.66e3;   % V
    Sbase = 100e6;     % VA
end
