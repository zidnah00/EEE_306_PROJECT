% VALIDATE_LOADFLOW  Run this FIRST, on its own, before anything else.
%   Confirms the BFS engine reproduces the published IEEE 33-bus
%   benchmark (proposal Step 2: "Validate the solver against the
%   published base-case result before proceeding.")
%
%   Expected output:
%     Total P loss  = 202.677 kW   (published: ~202.7 kW)
%     Min voltage   = 0.9131 p.u. at bus 18   (published: ~0.9131 p.u., bus 18)

clear; clc;

[branch, Pd, Qd, Vbase, Sbase] = ieee33_data();
N = numel(Pd);
topo = build_topology(branch, Vbase, Sbase, N);

[Vmag, ~, Ploss_kW, Qloss_kVAr, iters, converged] = bfs_loadflow(topo, Pd, Qd);

[minV, minBus] = min(Vmag);

fprintf('--- BFS Load-Flow Validation ---\n');
fprintf('Converged: %d, in %d iterations\n', converged, iters);
fprintf('Total P loss   = %.3f kW   (published ~202.7 kW)\n', Ploss_kW);
fprintf('Total Q loss   = %.3f kVAr\n', Qloss_kVAr);
fprintf('Min voltage    = %.4f p.u. at bus %d   (published ~0.9131 p.u. at bus 18)\n', minV, minBus);
fprintf('Total load     = %.0f kW, %.0f kVAr\n', sum(Pd), sum(Qd));

if abs(Ploss_kW - 202.7) < 0.5 && minBus == 18 && abs(minV - 0.9131) < 0.001
    fprintf('\n>>> VALIDATION PASSED. Solver matches published benchmark. <<<\n');
else
    fprintf('\n>>> VALIDATION FAILED -- check branch/bus data before proceeding. <<<\n');
end
