% RUN_CASES  Thin script wrapper around main(). This is the ONLY pipeline
%   in the project -- main.m does the actual work, so there is one code
%   path to maintain and defend. Edit the cfg fields below to change
%   parameters; see main.m's header for the full list and the rationale
%   behind each default.
%
%   If you'd rather drive this programmatically (parameter sweeps, batch
%   runs, sensitivity studies), call main(cfg) directly instead.

clear; clc; close all;

cfg = struct();
% --- defaults already give the best configuration; uncomment to explore ---
% cfg.RUN_PSO          = false;      % skip PSO for a faster run
% cfg.loadProfile      = 'single';   % simpler single-peak day
% cfg.fixedSizingPoint = 'peak';     % idealized (harder-to-beat) Case B
% cfg.plotPSO          = true;       % plot PSO's schedule instead of greedy's

results = main(cfg); %#ok<NASGU>  (left in the workspace for inspection)
