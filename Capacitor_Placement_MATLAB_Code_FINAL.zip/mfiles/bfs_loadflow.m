function [Vmag, Vcomplex, Ploss_kW, Qloss_kVAr, iters, converged] = ...
    bfs_loadflow(topo, Pd_kW, Qd_kVAr, cap_kVAr, tol, max_iter)
% BFS_LOADFLOW  Backward-Forward Sweep load-flow solver for a radial
%   distribution feeder. Converges reliably where Newton-Raphson is
%   ill-conditioned on high R/X distribution lines (per proposal Step 2).
%
%   INPUTS
%     topo      : struct from build_topology()
%     Pd_kW     : [N x 1] real power demand at each bus (kW), bus1=0
%     Qd_kVAr   : [N x 1] reactive power demand at each bus (kVAr), bus1=0
%     cap_kVAr  : [N x 1] capacitor reactive-power injection at each bus
%                 (kVAr). Optional — defaults to zero (no capacitors).
%                 A capacitor SUPPLIES reactive power, so it reduces the
%                 net reactive demand seen by the network.
%     tol       : voltage-mismatch convergence tolerance (p.u.). Default 1e-8.
%     max_iter  : maximum sweep iterations. Default 100.
%
%   OUTPUTS
%     Vmag       : [N x 1] voltage magnitude at each bus (p.u.)
%     Vcomplex   : [N x 1] complex voltage phasor at each bus (p.u.)
%     Ploss_kW   : total real power (I^2R) loss across all branches (kW)
%     Qloss_kVAr : total reactive power loss across all branches (kVAr)
%     iters      : number of sweep iterations used
%     converged  : true/false — did it converge within max_iter?
%
%   VALIDATION: with ieee33_data()'s nominal Pd/Qd and cap_kVAr = zeros,
%   this must return Ploss_kW = 202.677 and min(Vmag) = 0.9131 at bus 18.

    N = topo.N;
    if nargin < 4 || isempty(cap_kVAr); cap_kVAr = zeros(N,1); end
    if nargin < 5 || isempty(tol);      tol = 1e-8;            end
    if nargin < 6 || isempty(max_iter); max_iter = 100;        end

    Qnet_kVAr = Qd_kVAr(:) - cap_kVAr(:);
    Sload_pu  = complex(Pd_kW(:), Qnet_kVAr) * 1e3 / topo.Sbase;  % per-unit complex demand

    V = ones(N,1);           % flat start, complex voltage
    converged = false;
    Ibranch = zeros(N,1);

    for it = 1:max_iter
        Vold = V;

        % ---- Backward sweep: accumulate branch currents, leaves -> root ----
        Ibranch(:) = 0;
        for idx = 1:N
            u = topo.rev_order(idx);
            if u == 1
                continue;
            end
            Iload = conj(Sload_pu(u) / V(u));
            kids  = topo.children{u};
            Ich = 0;
            for j = 1:numel(kids)
                Ich = Ich + Ibranch(kids(j));
            end
            Ibranch(u) = Iload + Ich;
        end

        % ---- Forward sweep: update voltages, root -> leaves ----
        for idx = 1:N
            u = topo.order(idx);
            if u == 1
                V(u) = complex(1,0);
                continue;
            end
            p = topo.parent(u);
            z = complex(topo.Rpu(u), topo.Xpu(u));
            V(u) = V(p) - Ibranch(u) * z;
        end

        if max(abs(V - Vold)) < tol
            converged = true;
            iters = it;
            break;
        end
    end
    if ~converged
        iters = max_iter;
    end

    % ---- Total losses from final branch currents ----
    Ploss_pu = 0;
    Qloss_pu = 0;
    for u = 2:N
        z = complex(topo.Rpu(u), topo.Xpu(u));
        Sloss = abs(Ibranch(u))^2 * z;
        Ploss_pu = Ploss_pu + real(Sloss);
        Qloss_pu = Qloss_pu + imag(Sloss);
    end
    Ploss_kW   = Ploss_pu * topo.Sbase / 1e3;
    Qloss_kVAr = Qloss_pu * topo.Sbase / 1e3;

    Vcomplex = V;
    Vmag     = abs(V);
end
