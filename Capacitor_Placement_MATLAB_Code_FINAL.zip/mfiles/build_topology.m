function topo = build_topology(branch, Vbase, Sbase, N)
% BUILD_TOPOLOGY  Precompute the radial-tree structure used by every
%   other function in this project (bfs_loadflow, compute_LSF_VSI, etc.)
%   so it only needs to be built once instead of on every call.
%
%   INPUTS
%     branch : [Nbranch x 4] = [fromBus, toBus, R(ohm), X(ohm)]
%     Vbase  : line voltage base (V)
%     Sbase  : system MVA base (VA)
%     N      : number of buses (33 for the IEEE 33-bus system)
%
%   OUTPUT topo (struct):
%     .N          number of buses
%     .parent     [N x 1] parent(i) = upstream bus feeding bus i (0 for root)
%     .Rpu, .Xpu  [N x 1] per-unit R/X of the branch feeding bus i
%     .children   {N x 1} cell array; children{i} = child bus numbers of i
%     .order      BFS order, root -> leaves (bus 1 first)
%     .rev_order  reverse of order, leaves -> root (needed for backward sweep)
%     .Vbase, .Sbase, .Zbase

    parent   = zeros(N,1);
    Rline    = zeros(N,1);
    Xline    = zeros(N,1);
    children = cell(N,1);

    for k = 1:size(branch,1)
        f = branch(k,1);
        t = branch(k,2);
        parent(t) = f;
        Rline(t)  = branch(k,3);
        Xline(t)  = branch(k,4);
        children{f}(end+1) = t;
    end

    % Breadth-first traversal from the root (bus 1) to get a valid
    % processing order: every bus appears AFTER its parent.
    order = zeros(N,1);
    order(1) = 1;
    queue = 1;
    head = 1;
    while head <= numel(queue)
        u = queue(head);
        head = head + 1;
        kids = children{u};
        for j = 1:numel(kids)
            queue(end+1) = kids(j); %#ok<AGROW>
        end
    end
    order = queue(:);
    rev_order = flipud(order);

    Zbase = Vbase^2 / Sbase;
    Rpu = Rline / Zbase;
    Xpu = Xline / Zbase;

    topo.N         = N;
    topo.parent    = parent;
    topo.Rpu       = Rpu;
    topo.Xpu       = Xpu;
    topo.children  = children;
    topo.order     = order;
    topo.rev_order = rev_order;
    topo.Vbase     = Vbase;
    topo.Sbase     = Sbase;
    topo.Zbase     = Zbase;
end
